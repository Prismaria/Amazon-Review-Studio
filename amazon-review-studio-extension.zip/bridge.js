/**
 * Amazon Review Studio - Extension Bridge
 * Polyfills Greasemonkey/Tampermonkey APIs for Chrome Extension context.
 */

(function () {
    'use strict';

    // Standard polyfill for unsafeWindow
    window.unsafeWindow = window;

    // --- Storage APIs (using chrome.storage.local) ---

    // We use a prefix to keep extension-specific data separate if needed
    const STORAGE_KEY = 'ars_userscript_data';

    // Helper to get all data
    async function getInternalStorage() {
        return new Promise((resolve) => {
            chrome.storage.local.get([STORAGE_KEY], (result) => {
                resolve(result[STORAGE_KEY] || {});
            });
        });
    }

    // Helper to set all data
    async function setInternalStorage(data) {
        return new Promise((resolve) => {
            chrome.storage.local.set({ [STORAGE_KEY]: data }, () => {
                resolve();
            });
        });
    }

    window.GM_addStyle = function (css) {
        const style = document.createElement('style');
        style.textContent = css;
        (document.head || document.documentElement).appendChild(style);
        return style;
    };

    window.GM_getValue = function (key, defaultValue) {
        if (window.__ars_storage_cache && key in window.__ars_storage_cache) {
            return window.__ars_storage_cache[key];
        }
        return defaultValue;
    };

    window.GM_setValue = async function (key, value) {
        const data = await getInternalStorage();
        data[key] = value;
        await setInternalStorage(data);
        if (window.__ars_storage_cache) window.__ars_storage_cache[key] = value;
    };

    window.GM_deleteValue = async function (key) {
        const data = await getInternalStorage();
        delete data[key];
        await setInternalStorage(data);
        if (window.__ars_storage_cache) delete window.__ars_storage_cache[key];
    };

    window.GM_listValues = async function () {
        const data = await getInternalStorage();
        return Object.keys(data);
    };

    // --- Network APIs ---

    /**
     * Determines whether a URL is "external" (i.e. not on any Amazon domain).
     * External requests must be proxied through the background service worker
     * to avoid CORS errors, since content scripts are bound to their host origin.
     */
    function isExternalUrl(url) {
        try {
            const { hostname } = new URL(url);
            return !hostname.match(/\bamazon\.[a-z.]+$/i);
        } catch {
            return false; // Relative URL — treat as same-origin
        }
    }

    window.GM_xmlhttpRequest = function (details) {
        const { method = 'GET', url, headers, data, onload, onerror } = details;

        if (isExternalUrl(url)) {
            // Route through the background service worker; it has host_permissions
            // for external URLs (e.g. pastebin.com) and is NOT subject to CORS.

            const prepareAndSend = async (dataPayload) => {
                chrome.runtime.sendMessage(
                    { type: 'EXTERNAL_FETCH', method, url, data: dataPayload, headers: headers || {} },
                    (response) => {
                        if (chrome.runtime.lastError) {
                            if (onerror) onerror(new Error(chrome.runtime.lastError.message));
                            return;
                        }
                        if (!response) {
                            if (onerror) onerror(new Error('No response from background'));
                            return;
                        }
                        if (response.error) {
                            if (onerror) onerror(new Error(response.error));
                            return;
                        }
                        if (onload) {
                            onload({
                                status: response.status,
                                statusText: response.statusText,
                                responseText: response.responseText,
                                headers: {},
                                finalUrl: url,
                            });
                        }
                    }
                );
            };

            if (data instanceof Blob) {
                const reader = new FileReader();
                reader.onloadend = () => prepareAndSend(reader.result);
                reader.readAsDataURL(data);
            } else {
                prepareAndSend(data);
            }
        } else {
            // Same-origin (Amazon) requests can use fetch directly.
            fetch(url, { method, headers: headers || {}, body: data })
                .then(async (response) => {
                    const text = await response.text();
                    if (onload) onload({
                        status: response.status,
                        statusText: response.statusText,
                        responseText: text,
                        headers: Object.fromEntries(response.headers.entries()),
                        finalUrl: response.url,
                    });
                })
                .catch((err) => {
                    if (onerror) onerror(err);
                });
        }

        return { abort: () => { } }; // Dummy abort
    };

    /**
     * Fetches an image URL and returns a DataURL.
     * Used for capturing Amazon thumbnails and Catbox images safely across origins.
     */
    window.GM_fetchImage = function (url) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ type: 'FETCH_IMAGE', url }, (response) => {
                if (chrome.runtime.lastError) return reject(chrome.runtime.lastError);
                if (response.error) return reject(new Error(response.error));
                resolve(response.dataUrl);
            });
        });
    };

    /**
     * Uploads a file to an external API (like Catbox) using the background script.
     * Bypasses CORS and allows FormData with binary data.
     */
    window.GM_upload = function (url, fields, files) {
        return new Promise((resolve, reject) => {
            // Convert any Blobs/Files in files array to Base64 first for messaging
            const filePromises = files.map(async (f) => {
                if (f.blob instanceof Blob) {
                    return new Promise((res) => {
                        const reader = new FileReader();
                        reader.onloadend = () => res({ ...f, base64: reader.result });
                        reader.readAsDataURL(f.blob);
                    });
                }
                return f;
            });

            Promise.all(filePromises).then((processedFiles) => {
                chrome.runtime.sendMessage({
                    type: 'EXTERNAL_UPLOAD',
                    url,
                    fields,
                    files: processedFiles
                }, (response) => {
                    if (chrome.runtime.lastError) return reject(chrome.runtime.lastError);
                    if (response.error) return reject(new Error(response.error));
                    resolve(response.responseText);
                });
            });
        });
    };

    /**
     * Theme & Icon Management
     * Detects browser/system theme or extension setting and syncs the toolbar icon.
     */
    function syncIconTheme() {
        if (!chrome.runtime?.id) return;

        try {
            chrome.storage.local.get(['popupTheme'], (result) => {
                if (chrome.runtime.lastError) return;

                const isSystemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                const popupTheme = result.popupTheme;

                const isDark = popupTheme
                    ? (popupTheme === 'dark' || popupTheme === 'black')
                    : isSystemDark;

                chrome.runtime.sendMessage({
                    type: 'SET_ICON_THEME',
                    isDark
                }).catch(() => { }); // Ignore errors from orphaned scripts
            });
        } catch (e) {
            if (e.message?.includes('context invalidated')) return;
            console.error('[Review Studio] Failed to sync icon theme:', e);
        }
    }

    // Initial sync
    syncIconTheme();

    // Watch for system theme changes
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    if (mediaQuery.addEventListener) {
        mediaQuery.addEventListener('change', syncIconTheme);
    } else if (mediaQuery.addListener) {
        mediaQuery.addListener(syncIconTheme);
    }

    // Watch for popup theme changes in storage
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes.popupTheme) {
            syncIconTheme();
        }
    });

    // Also check on interval just in case (Amazon is an SPA)
    setInterval(syncIconTheme, 10000);

    console.log('[Review Studio] Extension Bridge Loaded');
})();
